<?php

    // Tek argüman
    do_action( $tag, $arg );

    // Çoklu argümanlar
    do_action( $tag, $arg_a, $arg_b, $etc );

    // Çoklu argümanlar
    do_action_ref_array( $tag, $args );


?>