<?php 

remove_filter( 'the_content', 'do_shortcode', 11 );

?>