'wp_title' =>
  array (
      10 =>
          array (
              'wptexturize' =>
                  array (
                      'function' => 'wptexturize',
                      'accepted_args' => 1,
                  ),
              'convert_chars' =>
                  array (
                      'function' => 'convert_chars',
                      'accepted_args' => 1,
                  ),
              'esc_html' =>
                  array (
                      'function' => 'esc_html',
                      'accepted_args' => 1,
                  ),
          ),
      11 =>
          array (
              'capital_P_dangit' =>
                  array (
                      'function' => 'capital_P_dangit',
                      'accepted_args' => 1,
                  ),
          ),
  )