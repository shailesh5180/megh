<?php

    require_once( 'hook_debugging_functions.php' );
    list_hooks();

?>