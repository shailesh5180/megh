# tutsplus-custom-post-type-taxonomy-archive
A plugin to support the tutsplus tutorial on using a custom taxonomy to add blog posts to custom post type pages in WordPress
