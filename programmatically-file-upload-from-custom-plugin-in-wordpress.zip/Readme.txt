Author: Yogesh singh
Author URL: http://makitweb.com/
Author Email: yogesh@makitweb.com
Tutorial Link: http://makitweb.com/programmatically-file-upload-from-custom-plugin-in-wordpress/

Instructions -

## Copy customplugin folder in wp-content/plugins/ directory.
## Login to your WordPress admin dashboard and navigate to plugins menu.
## Activate customplugin plugin.

OR 

## You can also directly upload zip of customplugin directory from WordPress admin dashboard from plugins->Add New.
## Click on the Upload Plugin and select zip file.
## Click Install Now button.
## After installing click Activate Plugin button.
