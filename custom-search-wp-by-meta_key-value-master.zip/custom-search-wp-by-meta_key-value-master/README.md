# custom search WP by multiple meta_key value.

##### based on the answer of Vin Fugen, i changed a little bit to get my desired result.


it will only display results that belong to those meta fields.
