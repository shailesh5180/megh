 <script type="text/javascript">
    
   function get_data()
   {
        let partner_tot_comm = jQuery("#dd_partner_name :selected").attr("data-commission");

        jQuery("#total_commission").val(partner_tot_comm);

        var pay_comm = jQuery("#pay_commi").val();

        var rem_comm = partner_tot_comm - pay_comm;
       
        jQuery("#avil_comm").val(rem_comm);

        let partner_name1 = jQuery("#dd_partner_name :selected").text();

        jQuery("#partner_name").val(partner_name1);
   }

  
   function update_commission()
   {
        let partner_tot_comm = jQuery("#delivery_name").val();

        let totalcommission =  jQuery("#total_commission").val();

        let availablecommission = jQuery("#avil_comm").val();

        let avil_comm_first = jQuery("#avil_comm_first").val();
        
        let pay_hidden = jQuery("#pay_hidden").val();

        let pay_comm = jQuery("#pay_commi").val();

        let totalpaidamount = (avil_comm_first*1) + (pay_hidden*1);

        let totallstamount = (totalpaidamount*1) - (pay_comm*1);

        jQuery("#avil_comm").val(totallstamount);
      
   }
   
 </script>

 <?php
  global $wpdb;

  $query = "SELECT 
                  partner_id,
                  user_login,
                  sum(partner_commission) as partner_commission  
            FROM {$wpdb->prefix}users 
            INNER JOIN {$wpdb->prefix}usermeta 
              ON {$wpdb->prefix}users.id = {$wpdb->prefix}usermeta.user_id 
            right JOIN {$wpdb->prefix}lddfw_orders 
              ON {$wpdb->prefix}lddfw_orders.partner_id={$wpdb->prefix}users.id 
            where 
                {$wpdb->prefix}usermeta.meta_key='lddfw_partner_account' 
            GROUP BY {$wpdb->prefix}lddfw_orders.partner_id DESC";  

      $data = $wpdb->get_results($query,ARRAY_A);
// print_r($data);die;

    ?>

<div class="container wpowt-lib-cont">

    <div class="row owt-inner-row">
        <div class="panel panel-primary">
            <div class="panel-heading wpowt-lib-bg">
                <?php
                if (isset($params['action']) && $params['action'] == "edit") {
                    echo 'Edit Commission';
                } elseif (isset($params['action']) && $params['action'] == "view") {
                    echo 'View Commission';
                } else {
                    echo 'Create Pay Commission';
                }
                ?>
                <a href="admin.php?page=shipmint-manage-commission" class="btn btn-danger pull-right owt-btn-right owt-btn-top wpowt-lib-btn "><span class="dashicons dashicons-controls-back"></span> Back</a>
            </div>
            <div class="panel-body">

                <form action="javascript:void(0)" id="shipmint-frm-add-pay-commission" method="post">
                    <div class="col-sm-8">


                        <?php if (isset($params['action']) && $params['action'] == "edit" || isset($params['action']) && $params['action'] == "view") { ?>
                        <div class="form-group">
                            <label for="delivery_name">Delivery Partner Name:</label>
                            <input type="text" required readonly class="form-control" id="delivery_name" value="<?php echo isset($params['commission_data']['name']) ? esc_attr($params['commission_data']['name']) : ""; ?>" name="delivery_name">
                            <input type="hidden" required readonly class="form-control" id="delivery_id" value="<?php echo isset($params['commission_data']['id']) ? esc_attr($params['commission_data']['id']) : ""; ?>" name="delivery_id">
                        </div>
                          <input type="hidden" class="form-control" id="partner_id" value="<?php echo isset($params['commission_data']['partner_id']) ? esc_attr($params['commission_data']['partner_id']) : ""; ?>" name="partner_id">
                       
                         <input type="hidden" name="partner_name" id="partner_name">
                        <?php }elseif (isset($params['action']) && $params['action'] == "add") {  ?>

                        <div class="form-group">
                           <label for="delivery_name">Delivery Partner Name:</label>
                           <input type="hidden"  value="<?php echo $value['partner_id']; ?>" id="delivery_name_id">
                            <?php 

                              $d_name = '';
                              $d_name = ' <select id="dd_partner_name" name="dd_partner_name" onchange="get_data()" class="form-control">';
                              $d_name .= ' <option value="">Select Partner</option>';

                            foreach($data as $key => $value)
                             {
                                $partnerid = $value['partner_id'];
                             
                                $totalpaid_commissioncheck = $wpdb->get_results(
                                                $wpdb->prepare("SELECT id, last_total_commission from `{$wpdb->prefix}lddfw_commission` WHERE `partner_id` = %d",
                                                  $partnerid));

                                if(!empty($totalpaid_commissioncheck))
                                {
                                   $totalpaid_commission = $wpdb->get_results(
                                   $wpdb->prepare("SELECT id, partner_id, last_total_commission, name from `{$wpdb->prefix}lddfw_commission` WHERE `partner_id` = %d order by id desc limit 1",
                                                      $partnerid));
                                   $d_name .=  "<option data-commission=".$totalpaid_commission[0]->last_total_commission."  
                                              value=".$totalpaid_commission[0]->partner_id.">".$totalpaid_commission[0]->name."</option>"; 
                                }
                                
                                if($value['partner_id']!==$totalpaid_commission[0]->partner_id)
                                {
                                  $d_name .=  "<option data-commission=".$value['partner_commission']."  value=".$value['partner_id'].">".ucwords($value['user_login'])."</option>";
                                }
                                
                               
                             }
                             $d_name .='</select>';

                             echo $d_name;

                            ?>
                            
                        </div>
                       <input type="hidden" name="partner_name" id="partner_name">

                        <?php } ?> 

                        <?php if (isset($params['action']) && $params['action'] == "edit" || isset($params['action']) && $params['action'] == "view") { ?>

                            <div class="form-group">
                                <label for="txtname">Total Commission</label>
                                <input type="number" required readonly  id="total_commission" value="<?php echo isset($params['commission_data']['total_commission']) ? esc_attr($params['commission_data']['total_commission']) : ""; ?>" class="form-control" name="total_commission" placeholder="Enter Total Commission">
                            </div>


                          <?php }elseif (isset($params['action']) && $params['action'] == "add") {  ?>

                            <div class="form-group">
                                <label for="txtname">Total Commission</label>
                                <input type="number" required   id="total_commission" value="<?php echo isset($params['commission_data']['total_commission']) ? esc_attr($params['commission_data']['total_commission']) : ""; ?>" class="form-control" name="total_commission" placeholder="Enter Total Commission">
                            </div>

                          <?php } ?>  

                        <?php if (isset($params['action']) && $params['action'] == "edit" || isset($params['action']) && $params['action'] == "view") { ?>
                           <div class="form-group">
                            <label for="txtname">Pay Commission</label>
                            <input type="hidden"  class="form-control" id="pay_hidden" value="<?php echo isset($params['commission_data']['pay_commission']) ? esc_attr($params['commission_data']['pay_commission']) : ""; ?>" name="pay_hidden" placeholder="Enter Pay Commission"   required>

                             <input type="number"  class="form-control" id="pay_commi" value="<?php echo isset($params['commission_data']['pay_commission']) ? esc_attr($params['commission_data']['pay_commission']) : ""; ?>" name="pay_commi" placeholder="Enter Pay Commission" onchange="update_commission()"  required>
                        </div>
                       <?php }elseif (isset($params['action']) && $params['action'] == "add") {  ?>
                        <div class="form-group">
                            <label for="txtname">Pay Commission</label>
                         <input type="number"  class="form-control" id="pay_commi" value="<?php echo isset($params['commission_data']['pay_commission']) ? esc_attr($params['commission_data']['pay_commission']) : ""; ?>" name="pay_commi" placeholder="Enter Pay Commission" onchange="get_data()"  required>
                          </div>

                       <?php } ?>  

                        <?php if (isset($params['action']) && $params['action'] == "edit" || isset($params['action']) && $params['action'] == "view") { ?>
                            <div class="form-group">
                                <label for="txtname">Available Commission</label>
                                <input type="number" required readonly   id="avil_comm" value="<?php echo isset($params['commission_data']['avil_commission']) ? esc_attr($params['commission_data']['avil_commission']) : ""; ?>" class="form-control" name="avil_comm" placeholder="Enter Available" >

                                <input type="hidden" required   id="avil_comm_first" value="<?php echo isset($params['commission_data']['avil_commission']) ? esc_attr($params['commission_data']['avil_commission']) : ""; ?>" class="form-control" name="avil_comm_first" placeholder="Enter Available" >
                            </div>
                         <?php }elseif (isset($params['action']) && $params['action'] == "add") {  ?>

                            <div class="form-group">
                                <label for="txtname">Available Commission</label>
                                <input type="number" required   id="avil_comm" value="<?php echo isset($params['commission_data']['avil_commission']) ? esc_attr($params['commission_data']['avil_commission']) : ""; ?>" class="form-control" name="avil_comm" placeholder="Enter Available" >
                            </div>
                          <?php } ?>  

                        <?php if (isset($params['action']) && $params['action'] == "edit" || isset($params['action']) && $params['action'] == "view") { ?>
                        <div class="form-group">
                            <label for="txtname">Pay By</label>
                            <input type="text" required class="form-control" id="pay_by" value="<?php echo isset($params['commission_data']['pay_by']) ? esc_attr($params['commission_data']['pay_by']) : ""; ?>" name="pay_by" placeholder="Enter Payment By">
                        </div>
                        <?php }elseif (isset($params['action']) && $params['action'] == "add") {  ?>

                        <div class="form-group">
                           <label for="pay_by">Pay By:</label>
                        
                          <select class="form-control" id="pay_by" name="pay_by" >
                              <option value="Cash">Cash</option>
                              <option value="Check">Check</option>
                              <option value="Bank">Bank</option>
                              
                          </select>
                        </div>
                        <?php } ?>   

                        <div class="form-group">
                            <label for="txtname">Referance Number</label>
                            <input type="number" required class="form-control" id="ref_no" value="<?php echo isset($params['commission_data']['referance_no']) ? esc_attr($params['commission_data']['referance_no']) : ""; ?>" name="ref_no" placeholder="Enter Referance No">
                        </div>

                      </div>
                  
                    <?php if (isset($params['action']) && $params['action'] != "view") { ?>
                        <div class="form-group">
                            <input type="hidden" name="opt_action" value="<?php echo $params['action']; ?>" />
                            <div class="col-sm-12 owt-text-align">
                                <button type="submit" class="btn btn-success wpowt-lib-btn"><i class="mdi mdi-check-outline"></i> Submit</button>
                            </div>
                        </div>
                    <?php } ?>
                </form>

            </div>

        </div>

    </div>
</div>