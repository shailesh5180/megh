<?php
/**
 *
 * Plugin Name:   Delivery Partner for Shipmint
 * Plugin URI:    https://shipmint.in/
 * Description:   Improve the way you deliver, manage Partner, assign Partner to orders, 
 * Version:       1.9.8
 * Author:        Shipmint
 * Author URI:    http://www.shipmint.in
 * Text Domain:   lddfw
 * Domain Path:   /languages
 *
 */

// If this file is called directly, abort.
if ( !defined( 'WPINC' ) ) {
    die;
}


$lddfw_plugin_basename = plugin_basename( __FILE__ );
$lddfw_plugin_basename_array = explode( '/', $lddfw_plugin_basename );
$lddfw_plugin_folder = $lddfw_plugin_basename_array[0];
$lddfw_delivery_partners_page = get_option( 'lddfw_delivery_partners_page', '' );



if ( !function_exists( 'lddfw_activate' ) ) {
    /**
     * Currently plugin version.
     */
    define( 'LDDFW_VERSION', '1.9.8' );
    /**
     * Define delivery partner page id.
     */
    define( 'LDDFW_PAGE_ID', $lddfw_delivery_partners_page );
    /**
     * Define plugin folder name.
     */
    define( 'LDDFW_FOLDER', $lddfw_plugin_folder );
    /**
     * Define plugin dir.
     */
    define( 'LDDFW_DIR', __DIR__ );
    
    /**
     * Define supported plugins.
     */
    $lddfw_plugins = array();
    $lddfw_multivendor = '';


      include_once( ABSPATH . 'wp-admin/includes/plugin.php' );


  
                
                if ( is_plugin_active( 'wc-frontend-manager/wc_frontend_manager.php' ) ) {
                    // WCFM.
                    $lddfw_plugins[] = 'wcfm';
                    $lddfw_multivendor = 'wcfm';
                }
                
                
                if ( is_plugin_active( 'dc-woocommerce-multi-vendor/dc_product_vendor.php' ) ) {
                    // WC Marketplace.
                    $lddfw_plugins[] = 'wcmp';
                    $lddfw_multivendor = 'wcmp';
                }
                
                
                if ( is_plugin_active( 'dokan-lite/dokan.php' ) ) {
                    // Dokan.
                    $lddfw_plugins[] = 'dokan';
                    $lddfw_multivendor = 'dokan';
                }
            
     
    define( 'LDDFW_PLUGINS', $lddfw_plugins );
    /**
     * Define multivendor plugin.
     */
    define( 'LDDFW_MULTIVENDOR', ( in_array( $lddfw_multivendor, LDDFW_PLUGINS, true ) ? $lddfw_multivendor : '' ) );
    /**
     * The code that runs during plugin activation.
     * This action is documented in includes/class-lddfw-activator.php
     *
     * @param array $network_wide network wide.
     */
    function lddfw_activate()
    {
        include_once plugin_dir_path( __FILE__ ) . 'includes/class-lddfw-activator.php';
        $activator = new LDDFW_Activator();
        $activator->activate();
    }
    
    /**
     * Check for free version
     *
     * @since 1.1.2
     * @return boolean
     */

     function lddfw_is_free()
    {
        
        return false;
    
    }

 
    
    /**
     * Get order custom fields.
     *
     * @since 1.1.2
     * @param int   $orderid order id.
     * @param array $posts custom fields array.
     * @return html
     */
    function lddfw_order_custom_fields__premium_only( $orderid, $posts )
    {
        $html = '';
        $counter = 0;
        foreach ( $posts as $post ) {
            $meta = get_post_meta( $post->ID, '', true );
            $meta = array_map( function ( $n ) {
                return $n[0];
            }, $meta );
            if ( 0 < $counter && '' !== $html ) {
                $html .= '<br>';
            }
            $field_value = '';
            foreach ( $meta as $key => $value ) {
                $value = preg_replace( '/\\s+/', ' ', $value );
                
                if ( '_' !== substr( $key, 0, 1 ) ) {
                    $post_meta = get_post_meta( $orderid, $key, true );
                    if ( '' !== $post_meta ) {
                        
                        if ( '' !== $value ) {
                            $field_value .= $value . $post_meta . ' ';
                        } else {
                            $field_value .= $post_meta . ' ';
                        }
                    
                    }
                }
            
            }
            if ( '' !== $field_value ) {
                $html .= $post->post_title . ': ' . $field_value;
            }
            $counter++;
        }
        return $html;
    }
    

    
    /**
     * Premium feature.
     *
     * @since 1.1.2
     * @param string $value text.
     * @return html
     */
    function lddfw_premium_feature( $value )
    {
        $result = $value;
        
        return $result;
    }
    
    /**
     * Currency symbol
     *
     * @since 1.6.3
     * @return html
     */
    function lddfw_currency_symbol()
    {
        $result = '';
        if ( function_exists( 'get_woocommerce_currency_symbol' ) ) {
            $result = get_woocommerce_currency_symbol();
        }
        return $result;
    }
    
    /**
     * Prices
     *
     * @param boolean $permission partner permission.
     * @param string  $price price.
     * @since 1.6.7
     * @return html
     */
    function lddfw_price( $permission, $price )
    {
        
        if ( true === $permission ) {
            return $price;
        } else {
            return '';
        }
    
    }
    
    /**
     * The code that runs during plugin deactivation.
     * This action is documented in includes/class-lddfw-deactivator.php
     */
    function lddfw_deactivate()
    {

        include_once plugin_dir_path( __FILE__ ) . 'includes/class-lddfw-activator.php';
        $activator = new LDDFW_Activator();

        include_once plugin_dir_path( __FILE__ ) . 'includes/class-lddfw-deactivator.php';
        $deactivator = new LDDFW_Deactivator($activator);
        $deactivator->deactivate();
    }
    
    /**
     * Begins execution of the plugin.
     *
     * Since everything within the plugin is registered via hooks,
     * then kicking off the plugin from this point in the file does
     * not affect the page life cycle.
     *
     * @since 1.0.0
     */
    function lddfw_run()
    {
        $plugin = new LDDFW();
        $plugin->run();
    }
    
    /**
     * Get delivery partner page url.
     *
     * @param string $params params.
     * @since 1.0.0
     */
    function lddfw_partners_page_url( $params )
    {

        $link = get_page_link( LDDFW_PAGE_ID );
         //print_r($link);die; 
        if ( '' !== $params ) {
            
            if ( strpos( $link, '?' ) !== false ) {
                $link = esc_url( $link ) . '&' . $params;
            } else {
                $link = esc_url( $link ) . '?' . $params;
            }
            
            $link .= '&rnd=' . wp_rand( 10000, 999999 );
        }
        
        return $link;
    }
    
    /**
     * Register_query_vars for delivery partner page.
     *
     * @since 1.0.0
     * @param array $vars query_vars array.
     * @return array
     */
    function lddfw_register_query_vars( $vars )
    {
        $vars[] = 'lddfw_screen';
        $vars[] = 'lddfw_orderid';
        $vars[] = 'lddfw_page';
        $vars[] = 'lddfw_dates';
        $vars[] = 'lddfw_reset_login';
        $vars[] = 'lddfw_reset_key';
        $vars[] = 'k';
        return $vars;
    }
    
    /**
     * Function that format the date for the plugin.
     *
     * @since 1.0.0
     * @param string $type part of the date.
     * @return statement
     */
    function lddfw_date_format( $type )
    {
        $date_format = get_option( 'date_format', '' );
        $time_format = get_option( 'time_format', '' );
        if ( 'date' === $type ) {
            
            if ( 'F j, Y' !== $date_format && 'Y-m-d' !== $date_format && 'm/d/Y' !== $date_format && 'd/m/Y' !== $date_format ) {
                return 'F j, Y';
            } else {
                return $date_format;
            }
        
        }
        if ( 'time' === $type ) {
            
            if ( 'g:i a' !== $time_format && 'g:i A' !== $time_format && 'H:i' !== $time_format ) {
                return 'g:i a';
            } else {
                return $time_format;
            }
        
        }
    }
    
    /**
     * Format address.
     *
     * @since 1.0.0
     * @param string $format address format.
     * @param array  $array address array.
     * @return string
     */
    function lddfw_format_address( $format, $array )
    {
        $address_1 = $array['street_1'];
        $address_2 = $array['street_2'];
        $city = $array['city'];
        $postcode = $array['zip'];
        $country = $array['country'];
        $state = $array['state'];
        if ( 'array' === $format ) {
            return $array;
        }
        
        if ( 'map_address' === $format ) {
            // Show state only for USA.
            if ( 'US' !== $array['country'] && 'United States (US)' !== $array['country'] ) {
                $state = '';
            }
            $address = $address_1 . ', ';
            $address .= $city;
            if ( !empty($state) || !empty($postcode) ) {
                $address .= ', ';
            }
            if ( !empty($state) ) {
                $address .= $state . ' ';
            }
            if ( !empty($postcode) ) {
                $address .= $postcode . ' ';
            }
            if ( !empty($country) ) {
                $address .= ' ' . $country;
            }
            $address = str_replace( '  ', ' ', trim( $address ) );
            $address = str_replace( ' ', '+', $address );
            return $address;
        }
        
        
        if ( 'address_line' === $format ) {
            // Show state only for USA.
            if ( 'US' !== $array['country'] && 'United States (US)' !== $array['country'] ) {
                $state = '';
            }
            $address = $address_1 . ', ';
            $address .= $city;
            if ( !empty($state) || !empty($postcode) ) {
                $address .= ', ';
            }
            if ( !empty($state) ) {
                $address .= $state . ' ';
            }
            if ( !empty($postcode) ) {
                $address .= $postcode . ' ';
            }
            if ( !empty($country) ) {
                $address .= ' ' . $country;
            }
            $address = str_replace( '  ', ' ', trim( $address ) );
            return $address;
        }
        
        
        if ( 'address' === $format ) {
            // Format address.
            // Show state only for USA.
            if ( 'US' !== $array['country'] && 'United States (US)' !== $array['country'] ) {
                $state = '';
            }
            $address = '';
            
            if ( !empty($array['first_name']) ) {
                $first_name = $array['first_name'];
                $last_name = $array['last_name'];
                $address = $first_name . ' ' . $last_name . '<br>';
            }
            
            if ( !empty($array['company']) ) {
                $address .= $array['company'] . '<br>';
            }
            $address .= $address_1;
            if ( !empty($address_2) ) {
                $address .= ', ' . $address_2 . ' ';
            }
            $address .= '<br>' . $city;
            if ( !empty($state) || !empty($postcode) ) {
                $address .= ', ';
            }
            if ( !empty($state) ) {
                $address .= $state . ' ';
            }
            if ( !empty($postcode) ) {
                $address .= $postcode . ' ';
            }
            if ( !empty($country) ) {
                $address .= '<br>' . $country;
            }
            return $address;
        }
    
    }
    
    /**
     * Function that clear_cache.
     *
     * @param string $type type.
     * @param int    $partner_id partner id.
     * @since 1.7.3
     * @return void
     */
    function lddfw_delete_cache( $type, $partner_id )
    {
        // Delete partner cache.
        if ( 'partner' === $type ) {
            
            if ( '' !== $partner_id && '-1' !== $partner_id && false !== $partner_id ) {
                $transient_key = 'lddfw-partner-' . $partner_id . '-orders-count-' . date_i18n( 'Y-m-d' );
                delete_transient( $transient_key );
            }
        
        }
        // Delete orders cache.
        if ( 'orders' === $type ) {
            wp_cache_delete( 'lddfw_claim_orders', 'lddfw_cache_group' );
        }
    }
    
    /**
     * Function that uninstall the plugin.
     *
     * @since 1.0.0
     * @return void
     */
    function lddfw_fs_uninstall_cleanup()
    {
      
                // Delete all custom_fields.
                $allposts = get_posts( array(
                    'post_type'   => 'lddfw_custom_fields',
                    'numberposts' => -1,
                ) );
                foreach ( $allposts as $eachpost ) {
                    wp_delete_post( $eachpost->ID, true );
                }
                // Delete all custom_fields terms.
                $terms = get_terms( 'lddfw_custom_fields_sections', array(
                    'fields'     => 'ids',
                    'hide_empty' => false,
                ) );
                foreach ( $terms as $value ) {
                    wp_delete_term( $value, 'lddfw_custom_fields_sections' );
                }
                // Unregister custom_fields.
                unregister_taxonomy( 'lddfw_custom_fields_sections' );
                unregister_post_type( 'lddfw_custom_fields' );
          
    }
    
   
            /**
             * The code that runs during plugin activation.
             * Deactive free plugin version.
             */
            function lddfw_deactivate_lite_version__premium_only()
            {
                activate_plugins( 'delivery-boys-for-shipmint/delivery-boys-for-shipmint.php' );
            }
        
      
}

register_activation_hook( __FILE__, 'lddfw_activate' );
register_deactivation_hook( __FILE__, 'lddfw_deactivate' );
/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-lddfw.php';
add_filter( 'query_vars', 'lddfw_register_query_vars' );
lddfw_run();