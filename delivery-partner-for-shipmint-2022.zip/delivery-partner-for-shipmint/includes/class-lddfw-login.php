<?php
/**
 * partner Login.
 *
 * All the login functions.
 *
 * @package    LDDFW
 * @subpackage LDDFW/includes
 * @author     powerfulwp <cs@powerfulwp.com>
 */

/**
 * partner Login.
 *
 * All the login functions.
 *
 * @package    LDDFW
 * @subpackage LDDFW/includes
 * @author     powerfulwp <cs@powerfulwp.com>
 */
class LDDFW_Login {

	/**
	 * partners logout.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function lddfw_logout() {

		// Set availability off.
		$user = wp_get_current_user();
		$user_id = $user->ID;
		$user = new WP_User( $user_id, '', get_current_blog_id() );

		if ( in_array( 'partner', (array) $user->roles, true ) ) {
			$partner_id = $user->ID;
			update_user_meta( $partner_id, 'lddfw_partner_availability', '0' );
		}

		wp_logout();
		header( 'Location: ' . lddfw_partners_page_url( '' ) );
		exit;
	}
	/**
	 * partners login page.
	 *
	 * @since 1.0.0
	 * @return html
	 */
	public function lddfw_login_screen() {
	    
	    $logo = get_theme_mod( 'custom_logo' );
        $image = wp_get_attachment_image_src( $logo , 'full' );
        $image_url = $image[0];
        $image_width = $image[1];
        $image_height = $image[2];

		// Login page.
		$html = '<div class="lddfw_page" id="lddfw_login" style="display:none;">
				<div class="container-fluid lddfw_cover">
					<div class="row">
						<div class="col-12">
						<img src='.$image_url.' class="site_logo" />
						</div>
					</div>
				</div>
				<div class="container">
					<div class="row">
						<div class="col-12">
							<h1>' . esc_html( __( 'Login', 'lddfw' ) ) . '</h1>
							<p>' . esc_html( __( 'Enter your details below to continue.', 'lddfw' ) ) . '</p>
							<form method="post" name="lddfw_login_frm" id="lddfw_login_frm" action="' . esc_url( admin_url( 'admin-ajax.php' ) ) . '" nextpage="' . lddfw_partners_page_url( 'lddfw_screen=dashboard' ) . '">
							<div class="lddfw_alert_wrap"></div>

							<input type="text" autocapitalize=off class="form-control form-control-lg"  autocomplete="username" placeholder="' . esc_attr( __( 'Email', 'lddfw' ) ) . '" name="lddfw_login_email" id="lddfw_login_email"  value="">
								<input type="password" autocomplete="current-password" autocapitalize=off class="form-control form-control-lg" placeholder="' . esc_attr( __( 'Password', 'lddfw' ) ) . '" name="lddfw_login_password" id="lddfw_login_password" value="">
								<button class="lddfw_submit_btn btn btn-lg btn-primary btn-block" type="submit">
								' . esc_html( __( 'Login', 'lddfw' ) ) . '
								</button>
								<button style="display:none" class="lddfw_loading_btn btn-lg btn btn-block btn-primary" type="button" disabled>
								<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
								' . esc_html( __( 'Loading', 'lddfw' ) ) . '
								</button>
								<a href="#" id="lddfw_forgot_password_link">' . esc_html( __( 'Forgot password?', 'lddfw' ) ) . '</a>
							</form>
						</div>';
		
				// Delivery partner application link.
				if ( '1' === get_option( 'lddfw_partner_application', '' ) ) {
					$html .= '<div class="col-12 text-center"><a href="https://shipmint.in/delivery-partner-registration/" id="lddfw_application_link">' . esc_html( __( 'New partner? Apply for Delivery partner.', 'lddfw' )) . '</a></div>';
				}
		

		$html .= '</div>
				</div>
				</div>
				';
		return $html;
	}


	/**
	 * User login.
	 *
	 * @param object $user user object.
	 * @param string $password password.
	 * @since 1.5.0
	 */
	public static function lddfw_user_login( $user, $password ) {
		$user_login             = $user->user_login;
		$creds                  = array();
		$creds['user_login']    = $user_login;
		$creds['user_password'] = $password;
		$creds['remember']      = true;
		$user                   = wp_signon( $creds, false );
		$user_id                = $user->ID;
		wp_set_current_user( $user_id, $user_login );
		wp_set_auth_cookie( $user_id, true, false );
		do_action( 'wp_login', $user_login, $user );
		// Perform the login.
		$user = wp_signon( $creds, is_ssl() );
	}

	/**
	 * partners login.
	 *
	 * @since 1.0.0
	 * @return json
	 */
	public function lddfw_login_partner() {
		$error  = '';
		$result = '0';
		// Security check.
		if ( isset( $_POST['lddfw_wpnonce'] ) ) {
			 
				if ( isset( $_POST['lddfw_login_email'] ) ) {
					$email = sanitize_email( wp_unslash( $_POST['lddfw_login_email'] ) );
				}
				if ( isset( $_POST['lddfw_login_password'] ) ) {
					$password = sanitize_text_field( wp_unslash( $_POST['lddfw_login_password'] ) );
				}

				// Check for empty fields.
				if ( empty( $email ) ) {
					// No email.
					$error = __( 'The email field is empty.', 'lddfw' );
				} else {
					if ( empty( $password ) ) {
						// No password.
						$error = __( 'The password field is empty.', 'lddfw' );
					} else {
						if ( ! filter_var( $email, FILTER_VALIDATE_EMAIL ) ) {
							// Invalid Email.
							$error = __( 'The email is invalid.', 'lddfw' );
						} else {
							// Check if user exists in WordPress database.
							$user = get_user_by( 'email', $email );

							// Bad email.
							if ( ! $user ) {
								$error = __( 'Either the email or password you entered is invalid.', 'lddfw' );
							} else {

								$user_id = $user->ID;
								$user = new WP_User( $user_id, '', get_current_blog_id() );

								// Check password.
								if ( ! wp_check_password( $password, $user->user_pass, $user->ID ) ) {
									// Bad password.
									$error = __( 'Either the email or password you entered is invalid.', 'lddfw' );
								} else {
									if ( ! in_array( 'partner', (array) $user->roles, true ) ) {
										$error = __( 'You are not a registered delivery partner.', 'lddfw' );
									} else {
											$lddfw_partner_account = get_user_meta( $user->ID, 'lddfw_partner_account', true );
										if ( '1' !== $lddfw_partner_account ) {
											$error = __( 'Your account is not active, please contact the dispatch center.', 'lddfw' );
										} else {
											$this->lddfw_user_login( $user, $password );
											$error  = '';
											$result = '1';
										}
									}
								}
							}
						}
					}
				}
			 
		}
			return "{\"result\":\"$result\",\"error\":\"$error\"}";
	}
}
