<?php
/**
 * Admin panel metaboxes
 *
 * @link  http://www.powerfulwp.com
 * @since 1.0.0
 *
 * @package    LDDFW
 * @subpackage LDDFW/includes
 * @author     powerfulwp <cs@powerfulwp.com>
 */

/**
 * Admin panel metaboxes
 *
 * @link  http://www.powerfulwp.com
 * @since 1.0.0
 *
 * @package    LDDFW
 * @subpackage LDDFW/includes
 * @author     powerfulwp <cs@powerfulwp.com>
 */
function lddfw_metaboxes() {
	add_meta_box(
		'lddfw_metaboxes',
		__( 'Delivery Partner', 'lddfw' ),
		'lddfw_metaboxes_build',
		'shop_order',
		'side',
		'default'
	);
}

add_action( 'add_meta_boxes', 'lddfw_metaboxes' );

/**
 * Building the metabox
 */
function lddfw_metaboxes_build() {
	global $post;

	echo '<input type="hidden" name="lddfw_metaboxes_key" id="lddfw_metaboxes_key" value="' . esc_attr( wp_create_nonce( 'lddfw-save-order' ) ) . '" />';

	$lddfw_partnerid = get_post_meta( $post->ID, 'lddfw_partnerid', true );

	echo '<div class="lddfw-partner-box">
	<label>' . esc_html( __( 'Partner', 'lddfw' ) ) . '</label>';
	$partners = LDDFW_partner::lddfw_get_partners();

	echo esc_html( lddfw_partner_partners_selectbox( $partners, $lddfw_partnerid, $post->ID, '' ) );

	
			// Partner Commission.
			echo '<p>
			<label>' . esc_html( __( 'Partner Commission', 'lddfw' ) ) . '</label>
			<br>' . lddfw_currency_symbol() . ' <input size="5" name="lddfw_partner_commission" id="lddfw_partner_commission" type="text" value="' . esc_attr( get_post_meta( $post->ID, 'lddfw_partner_commission', true ) ) . '">';

			$lddfw_partner_commission_note = get_post_meta( $post->ID, '_lddfw_partner_commission_note', true );
			if ( '' !== $lddfw_partner_commission_note ) {
				echo '<br>' . $lddfw_partner_commission_note;
			}
			echo '</p>';

			// Delivery Note to the partner.
			$lddfw_delivery_note_to_partner = get_post_meta( $post->ID, '_lddfw_delivery_note_to_partner', true );
			echo '<p>
			<label>' . esc_html( __( 'Note to the Partner', 'lddfw' ) ) . '</label>
			<textarea type="text" style="width: 100%;height: 50px;" name="_lddfw_delivery_note_to_partner" id="_lddfw_delivery_note_to_partner" class="input-text" >' . esc_attr( $lddfw_delivery_note_to_partner ) . '</textarea>';
			echo '</p>';


	
	/* partner note */
	$lddfw_partner_note = get_post_meta( $post->ID, 'lddfw_partner_note', true );
	if ( '' !== $lddfw_partner_note ) {
		echo '<p><label>' . esc_html( __( 'Partner Note', 'lddfw' ) ) . '</label><br>';
			echo $lddfw_partner_note;
			echo '</p>';
	}

	$lddfw_delivered_date = get_post_meta( $post->ID, 'lddfw_delivered_date', true );
	if ( '' !== $lddfw_delivered_date ) {
		echo '<p><label>' . esc_html( __( 'Delivered Date', 'lddfw' ) ) . '</label><br>';
		echo $lddfw_delivered_date;
		echo '</p>';
	}

	$lddfw_failed_attempt_date = get_post_meta( $post->ID, 'lddfw_failed_attempt_date', true );
	if ( '' !== $lddfw_failed_attempt_date ) {
		echo '<p><label>' . esc_html( __( 'Failed Attempt Date', 'lddfw' ) ) . '</label><br>';
		echo $lddfw_failed_attempt_date;
		echo '</p>';
	}



			// Signature.
			$lddfw_order_signature = get_post_meta( $post->ID, 'lddfw_order_signature' );
			if ( ! empty( $lddfw_order_signature ) ) {
				echo '<p><label>' . esc_html( __( 'Signature', 'lddfw' ) ) . '</label><br>';
				foreach ( array_reverse( $lddfw_order_signature ) as $value ) {
					echo '<a href="' . esc_attr( $value ) . '" class="lddfw_order_image" target="_blank"><img style="max-width:100%" src="' . esc_attr( $value ) . '"></a>';
				}
				echo '</p>';
			}

			// Photo.
			$lddfw_order_delivery_image = get_post_meta( $post->ID, 'lddfw_order_delivery_image' );
			if ( ! empty( $lddfw_order_delivery_image ) ) {
				echo '<p><label>' . esc_html( __( 'Photo', 'lddfw' ) ) . '</label><br>';
				foreach ( array_reverse( $lddfw_order_delivery_image ) as $value ) {
					echo '<a href="' . esc_attr( $value ) . '" class="lddfw_order_image" target="_blank"><img style="max-width:100%" src="' . esc_attr( $value ) . '"></a>';
				}
				echo '</p>';
			}
		
	echo '</div> ';
}
/**
 * partners selectbox.
 *
 * @param object $partners partners object.
 * @param int    $partner_id user id number.
 * @param int    $order_id order number.
 * @param string $type type.
 * @return void
 */
function lddfw_partner_partners_selectbox( $partners, $partner_id, $order_id, $type ) {
	if ( 'bulk' === $type ) {
		echo "<select name='lddfw_partnerid_" . esc_attr( $order_id ) . "' id='lddfw_partnerid_" . esc_attr( $order_id ) . "'>";
	} else {
		echo "<select name='lddfw_partnerid' id='lddfw_partnerid_" . esc_attr( $order_id ) . "' order='" . esc_attr( $order_id ) . "' class='widefat'>";
	}
	echo "<option value=''>" . esc_html( __( 'Assign a partner', 'lddfw' ) ) . '</option>
    ';
	$last_availability = '';
	foreach ( $partners as $partner ) {
		$partner_name    = $partner->display_name;
		$availability   = get_user_meta( $partner->ID, 'lddfw_partner_availability', true );
		$partner_account = get_user_meta( $partner->ID, 'lddfw_partner_account', true );
		$availability   = '1' === $availability ? esc_attr( __( 'Available', 'lddfw' ) ) : esc_attr( __( 'Unavailable', 'lddfw' ) ) ;
		$selected       = '';
		if ( intval( $partner_id ) === $partner->ID ) {
			$selected = 'selected';
		}
		if ( $last_availability !== $availability ) {
			if ( '' !== $last_availability ) {
				echo '</optgroup>';
			}
			echo '<optgroup label="' . esc_attr( $availability . ' ' . __( 'partners', 'lddfw' ) ) . '">';
			$last_availability = $availability;
		}
		if ( '1' === $partner_account || ( '1' !== $partner_account && intval( $partner_id ) === $partner->ID ) ) {
			echo '<option ' . esc_attr( $selected ) . ' value="' . esc_attr( $partner->ID ) . '">' . esc_html( $partner_name ) . '</option>';
		}
	}
	echo '</optgroup></select>';
}



/**
 * Save the Metabox Data
 *
 * @param int    $post_id post number.
 * @param object $post post object.
 */
function lddfw_partner_save_order_details( $post_id, $post ) {

	$partner = new LDDFW_partner();
	if (
		! isset( $_POST['lddfw_metaboxes_key'] )
		|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['lddfw_metaboxes_key'] ) ), 'lddfw-save-order' )
	) {
		return $post->ID;
	}

	
			// Save Partner Commissions.
			if ( isset( $_POST['lddfw_partner_commission'] ) ) {
				$lddfw_partner_commission = sanitize_text_field( wp_unslash( $_POST['lddfw_partner_commission'] ) );
				if ( is_numeric( $lddfw_partner_commission ) ) {
					lddfw_update_post_meta( $post_id, 'lddfw_partner_commission', $lddfw_partner_commission );
				} else {
					lddfw_delete_post_meta( $post_id, 'lddfw_partner_commission' );
				}
			}
			// Save delivery note to partner.
			if ( isset( $_POST['_lddfw_delivery_note_to_partner'] ) ) {
				$lddfw_delivery_note_to_partner = sanitize_text_field( wp_unslash( $_POST['_lddfw_delivery_note_to_partner'] ) );
				update_post_meta( $post_id, '_lddfw_delivery_note_to_partner', $lddfw_delivery_note_to_partner );
			}
	

	if ( isset( $_POST['lddfw_partnerid'] ) ) {
		$lddfw_partnerid                            = sanitize_text_field( wp_unslash( $_POST['lddfw_partnerid'] ) );
		$lddfw_partner_order_meta['lddfw_partnerid'] = $lddfw_partnerid;
	}

	foreach ( $lddfw_partner_order_meta as $key => $value ) {
		/**
		 * Cycle through the $thccbd_meta array!
		 */
		if ( 'revision' === $post->post_type ) {
			/**
			 * Don't store custom data twice
			 */
			return;
		}

		$value = implode( ',', (array) $value );
		$partner->assign_delivery_partner( $post->ID, $value, 'store' );
		if ( ! $value ) {
			/**
			 * Delete if blank
			 */
			lddfw_delete_post_meta( $post->ID, $key );
			
		}
	}
}
add_action( 'save_post', 'lddfw_partner_save_order_details', 10, 2 ); // Save the custom fields.
