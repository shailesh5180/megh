<?php

class LDDFW_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since 1.0.0
	 */
	public function lddfw_set_options() {

	
				// Create tracking page.
				lddfw_create_tracking_page__premium_only();

				// Create tracking table.
				lddfw_create_tracking_table__premium_only();

				// Create cron job.
				if ( ! wp_next_scheduled( 'lddfw_daily_event' ) ) {
					wp_schedule_event( time(), 'daily', 'lddfw_daily_event' );
				}
		

		// Create sync table.
		lddfw_create_sync_table();
		

		if ( ! get_option( 'lddfw_delivery_partners_page' ) ) {
			update_option( 'lddfw_sync_table', '2' );

			
					update_option( 'lddfw_tracking_table', '2' );
			

		} else {
			// Sync data to table.
			lddfw_sync_table();
		}

		// Create a delivery partner role.
		add_role(
			'partner',
			esc_html( __( 'Delivery Partner', 'lddfw' ) ),
			array(
				'read'         => true,
				'edit_posts'   => false,
				'delete_posts' => false,
			)
		);

		// Create the partners panel page for the first activation.
		lddfw_create_partners_panel_page();

		// Set default settings options.
		add_option( 'lddfw_out_for_delivery_status', 'wc-out-for-delivery' );
		add_option( 'lddfw_delivered_status', 'wc-completed' );
		add_option( 'lddfw_failed_attempt_status', 'wc-failed-delivery' );
		add_option( 'lddfw_partner_assigned_status', 'wc-partner-assigned' );
		add_option( 'lddfw_processing_status', 'wc-processing' );
		add_option( 'lddfw_sms_assign_to_partner_template', 'Hello [delivery_partner_first_name], order #[order_id] with [store_name] has been assigned to you. [delivery_partner_page]' );
		add_option( 'lddfw_sms_out_for_delivery_template', 'Hello [billing_first_name], status of your order #[order_id] with [store_name] has been changed to [order_status].' );
		add_option( 'lddfw_sms_start_delivery_template', 'Hello [billing_first_name], the delivery for order #[order_id] with [store_name] has been started. [estimated_time_of_arrival] [tracking_url]' );
		add_option( 'lddfw_whatsapp_assign_to_partner_template', 'Hello [delivery_partner_first_name], order #[order_id] with [store_name] has been assigned to you. [delivery_partner_page]' );
		add_option( 'lddfw_whatsapp_out_for_delivery_template', 'Hello [billing_first_name], status of your order #[order_id] with [store_name] has been changed to [order_status].' );
		add_option( 'lddfw_whatsapp_start_delivery_template', 'Hello [billing_first_name], the delivery for order #[order_id] with [store_name] has been started. [estimated_time_of_arrival] [tracking_url]' );

		add_option( 'lddfw_failed_delivery_reason_1', __( 'Refused by the recipient.', 'lddfw' ) );
		add_option( 'lddfw_failed_delivery_reason_2', __( 'Incorrect address.', 'lddfw' ) );
		add_option( 'lddfw_failed_delivery_reason_3', __( 'Failed delivery attempt.', 'lddfw' ) );
		add_option( 'lddfw_failed_delivery_reason_4', __( 'Item Lost.', 'lddfw' ) );
		add_option( 'lddfw_failed_delivery_reason_5', __( 'Item damaged.', 'lddfw' ) );
		add_option( 'lddfw_delivery_dropoff_1', __( 'Delivered to the customer.', 'lddfw' ) );
		add_option( 'lddfw_delivery_dropoff_2', __( 'Left at the front door.', 'lddfw' ) );
		add_option( 'lddfw_delivery_dropoff_3', __( 'Left with the neighbor.', 'lddfw' ) );
		

		
				add_option( 'lddfw_self_assign_delivery_partners', '1' );
				add_option( 'lddfw_auto_assign_delivery_partners', '1' );
				add_option( 'lddfw_sms_provider', 'twilio' );
				add_option( 'lddfw_whatsapp_provider', 'twilio' );
				add_option( 'lddfw_partner_photo_permission', '1' );
				add_option( 'lddfw_partner_name_permission', '1' );
				add_option( 'lddfw_partner_phone_permission', '1' );
				add_option( 'lddfw_partner_prices_permission', '1' );
				add_option( 'lddfw_partner_products_permission', '1' );
				add_option( 'lddfw_partner_commission_permission', '1' );
			


	}


	/**
	 * Short Description. (use period)
	 *
	 * @param array $network_wide network_wide array.
	 * @since 1.0.0
	 */
	public function activate() {

		

				if ( is_plugin_active( 'delivery-partner-for-shipmint/delivery-partner-for-shipmint' ) ) {
					add_action( 'update_option_active_plugins', 'lddfw_deactivate_lite_version__premium_only' );
				}
		

		if ( is_multisite()  ) {
			
			// Run the code for all sites in a Multisite network.
			foreach ( get_sites( array( 'fields' => 'ids' ) ) as $blog_id ) {
					switch_to_blog( $blog_id );
					$this->lddfw_set_options();
			}
				restore_current_blog();
		} else {
			$this->lddfw_set_options();
		}



		 global $wpdb;

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

        // table to store commission
        if ($wpdb->get_var("show tables like '" . $this->shipmint_tbl_commission() . "'") != $this->shipmint_tbl_commission()) {

            $sql_student = 'CREATE TABLE `' . $this->shipmint_tbl_commission() . '` (
                                  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                                  partner_id bigint(20) DEFAULT 0,
                                  name varchar(250) DEFAULT NULL,
                                  total_commission decimal(19,2) DEFAULT 0.00,
                                  user_id bigint(20) DEFAULT 0,
                                  pay_commission decimal(19,2) DEFAULT 0.00,
                                  avil_commission decimal(19,2) DEFAULT 0.00,
                                  last_total_commission decimal(19,2) DEFAULT 0.00,
                                  pay_by varchar(250) DEFAULT NULL,
                                  referance_no varchar(100) DEFAULT NULL,
                                  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
                                  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                                  PRIMARY KEY (id),
                                  KEY partner_id (partner_id)
                              ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;';

            dbDelta($sql_student);
        }

           // table to Tracking Partner
        if ($wpdb->get_var("show tables like '" . $this->shipmint_tbl_tracking_partner() . "'") != $this->shipmint_tbl_tracking_partner()) {

            $sql_partner_track = 'CREATE TABLE `' . $this->shipmint_tbl_tracking_partner() . '` (
                                 `id` int(11) NOT NULL AUTO_INCREMENT,
								 `partner_id` int(11) NOT NULL,
								 `latitude` varchar(155) NOT NULL,
								 `longitude` varchar(155) NOT NULL,
								 `partner_emailid` varchar(100) DEFAULT NULL,
								 `date` varchar(15) NOT NULL,
								 PRIMARY KEY (`id`)
                              ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;';

            dbDelta($sql_partner_track);
        }

	}

   public function shipmint_tbl_commission() {

        global $wpdb;
        return $wpdb->prefix . "lddfw_commission";
    }

   public function shipmint_tbl_tracking_partner() {

        global $wpdb;
        return $wpdb->prefix . "lddfw_tracking_partner";
    }


}
