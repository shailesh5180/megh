<?php
/**
 * Plugin Tracking.
 *
 * All the screens functions.
 *
 */


class LDDFW_Tracking {

	/**
	 * Tracking page.
	 *
	 * @since 1.4.0
	 * @return html
	 */
	public function tracking_page() {

		$html = '';

		// Get order id by order key.
		$lddfw_order = NEW LDDFW_Order();
		$order_key 	 = sanitize_text_field( wp_unslash( get_query_var( 'k' ) ) );
		$order_id	 = wc_get_order_id_by_order_key( 'wc_order_' . $order_key );

		$order		 = wc_get_order( $order_id );
		if( ! empty( $order ) ){

		// Get the partner id.
		$partner_id = get_post_meta( $order_id, 'lddfw_partnerid', true );

		// Order Status.
		$order_status = $order->get_status();

		// Check if partner exist.
		if ( '' !== $partner_id ){

		// Check if order is out for delivery.
		if ( get_option( 'lddfw_out_for_delivery_status', '' ) === 'wc-' . $order_status ){

		// Get permissions to show the partner info.
		$lddfw_partner_photo_permission = get_option( 'lddfw_partner_photo_permission', false );
		$lddfw_partner_name_permission  = get_option( 'lddfw_partner_name_permission', false );
		$lddfw_partner_phone_permission = get_option( 'lddfw_partner_phone_permission', false );
		$photo_permission              = false === $lddfw_partner_photo_permission || '1' === $lddfw_partner_photo_permission ? true : false;
		$name_permission               = false === $lddfw_partner_name_permission || '1' === $lddfw_partner_name_permission ? true : false;
		$phone_permission              = false === $lddfw_partner_phone_permission || '1' === $lddfw_partner_phone_permission ? true : false;
		$partner                        = get_user_by( 'id', $partner_id );
		$partner_name                   = ( ! empty ( $partner ) ) ? $partner->display_name : '';
		$partner_billing_phone    = get_user_meta( $partner_id, 'billing_phone', true );

		// ETA.
		$current_date        = date_i18n( 'Y-m-d H:i:s' );
		$delivery_start_date = get_post_meta( $order_id, '_lddfw_order_delivery_start', true );
		$route 				 = $order->get_meta( 'lddfw_order_route' );

		$seconds_diff = -1 ;
		if ( ! empty( $route ) && '' !== $delivery_start_date ) {
			$route_duration_value = $route['duration_value'];
			if ( '' !== $route_duration_value ) {
				$route_date_created   = $route['date_created'];
				$route_duration_text  = $route['duration_text'];
				$arrivel_date         = date( "Y-m-d H:i:s", ( strtotime( date( $delivery_start_date ) ) + $route_duration_value ) );
				$seconds_diff         = strtotime( $arrivel_date ) - strtotime( $current_date );
			}
		}

		$partner 		= new LDDFW_partner();
		$store          = new LDDFW_Store();
		$route   		= new LDDFW_Route();

		$lddfw_google_api_key = get_option( 'lddfw_google_api_key', '' );
		$seller_id	= $store->lddfw_order_seller( $order );

		// Get seller coordinates.
		$seller_geocode_coordinates = '';
		if ( '' !== $seller_id) {
			$route->set_seller_geocode( $seller_id );
			$coordinates = $route->get_seller_geocode( $seller_id );
			if ( false !== $coordinates && is_array( $coordinates ) ) {
				$seller_geocode_coordinates = $coordinates[0] . ',' . $coordinates[1];
			}
		} else {
			$route->set_store_geocode();
			$seller_geocode_coordinates = $route->get_store_geocode();
		}

		// Set order coordinates.
		$route->set_order_geocode( $order_id );

		// Get order coordinates.
		$geocode_array = get_post_meta( $order_id, '_lddfw_address_geocode', true );

		$destination_coordinates = '';
		if ( ! empty( $geocode_array ) && is_array( $geocode_array ) ) {
			if ( 'ZERO_RESULTS' === $geocode_array[0] ){
				// ZERO_RESULTS.
			}
			if ( ! empty( $geocode_array[1] ) ) {
				$destination_coordinates = $geocode_array[1];
			}
		}

		$html = '<div class="lddfw_tracking_content">';

		// Map.
		if ( '' !== $lddfw_google_api_key ) {
			$html .= '<script id="lddfw_google_map_script" async defer src="https://maps.googleapis.com/maps/api/js?key=' . $lddfw_google_api_key . '&callback=lddfw_tracking_map"></script>
			<div id="lddfw_map123" class="lddfw_map-main-outer"></div>';
		}

		// Counter.
			$html .= '<div id="lddfw_counter" style="display:none"></div>';

		  // Order status note.
			$html .= '
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div id="lddfw_tracking_order_status" class="text-center" >';
						if ( '' === $delivery_start_date ){
							$html .= '<h2>' . esc_html( __( 'Your order is out for delivery', 'lddfw' ) ). '</h2>';
						} else {
							$html .= '<h2>' . esc_html( __( 'Your order is on its way', 'lddfw' ) ). '</h2>';
						}
						$html .= '</div>
					</div>
				</div>
			</div>';

		// partner.
			$html .= '
	<div class="container-fluid" id="lddfw_tracking_partner">
		<div class="row">';

			$html .= '
			<div class="col-12">';

			// partner.
			$html .= '<div class="lddfw_box">
						<div class="row" id="lddfw_partner">';

			// partner info.
			$partner_info = '';
			if ( true === $name_permission ) {
				$partner_info .= '<div id="lddfw_tracking_partner_name">'. $partner_name . '</div>' ;
			}


			$lddfw_travel_mode= get_user_meta( $partner_id, 'lddfw_partner_travel_mode', true );
			$lddfw_partner_vehicle       = get_user_meta( $partner_id, 'lddfw_partner_vehicle', true );
			$lddfw_partner_licence_plate = get_user_meta( $partner_id, 'lddfw_partner_licence_plate', true );
			if ( '' !== $lddfw_partner_vehicle || '' !== $lddfw_partner_licence_plate ) {

					$partner_info .= '<div id="lddfw_tracking_partner_vehicle">';
					$partner_info .= esc_html( $lddfw_partner_vehicle ) . '<br>';
					$partner_info .= esc_html( $lddfw_partner_licence_plate )  ;
					$partner_info .= '</div>';

			}
 

			// partner photo.
			$partner_image_url = plugins_url() . '/' . LDDFW_FOLDER . '/public/images/user.png?ver=' . LDDFW_VERSION;
			if ( true === $photo_permission ) {
				$image_id = get_user_meta( $partner_id, 'lddfw_partner_image', true );
				if ( intval( $image_id ) > 0 ) {
					$image = wp_get_attachment_image_src( $image_id, 'medium' )[0];
					if ( '' !== $image ) {
						$partner_image_url = $image;
					}
				}
			}

			$html .= '
				<div class="col-9" style="padding-right:0px">
				<div id="lddfw_tracking_partner_image" style="background-image:url(\'' . $partner_image_url . '\')"></div>
			 	' . $partner_info . '</div>';

			// partner Phone and whatsapp.
			if ( '' !== $partner_billing_phone && true === $phone_permission ) {
				$html .= '<div class="col-3 text-center">
								<a class="btn lddfw_tracking_circle billing_phone btn-secondary btn-block" href="tel:' . esc_attr( $partner_billing_phone ) . '"><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="phone" class="svg-inline--fa fa-phone fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="currentColor" d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z"></path></svg></a>
							</div>

						';
			}

			$html .= '		</div>
							</div>
						</div>
					</div>
				</div>
			</div>

		   <script>
		   		let partner_marker;
		   		let lddfw_nonce = {"nonce":"' . esc_js(  wp_create_nonce( 'lddfw-nonce' ) ) . '"};
		   		let lddfw_order_id = "' . esc_js( $order_id ) . '";
		   		let lddfw_partner_id = "' . esc_js( $partner_id ) . '";
		   		let lddfw_ajax_url = "' . esc_url( admin_url( 'admin-ajax.php' ) ) . '";
		   		let lddfw_partners_tracking_timing = "'.esc_js( get_option( 'lddfw_partners_tracking_timing', '' ) ).'";
		   		let lddfw_tracking_status = "'.esc_js( get_user_meta( $partner_id, 'lddfw_tracking_status', true ) ).'";
				let tracking_origin = "'.esc_js( $seller_geocode_coordinates ).'";
				let tracking_destination = "'.esc_js( $destination_coordinates ).'";
				let tracking_driving_mode = "'.esc_js( $partner->get_partner_driving_mode( $partner_id, '' ) ).'";
				let tracking_min_text  = "<span class=tracking_min_text>' . esc_js( __( "Minutes", "lddfw" ) ) .'<br>' . esc_js( __( "until delivered", "lddfw" ) ) .'</span>";
				let lddfw_travel_mode = "'.esc_js( $lddfw_travel_mode ).'";
				const FULL_DASH_ARRAY = 283;
				const WARNING_THRESHOLD = 10;
				const ALERT_THRESHOLD = 5;

				const COLOR_CODES = {
				info: {
					color: "green"
				},
				warning: {
					color: "orange",
					threshold: WARNING_THRESHOLD
				},
				alert: {
					color: "red",
					threshold: ALERT_THRESHOLD
				}
				};

				const TIME_LIMIT = ' .$seconds_diff . ';
				let timePassed = 0;
				let timeLeft = TIME_LIMIT;
				let timerInterval = null;
				let remainingPathColor = COLOR_CODES.info.color;

				if ( ' . $seconds_diff . ' > -1 ){
					document.getElementById("lddfw_counter").style.display = "block";

				document.getElementById("lddfw_counter").innerHTML = `
				<div class="base-timer">
				<svg class="base-timer__svg" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
					<g class="base-timer__circle">
					<circle class="base-timer__path-elapsed" cx="50" cy="50" r="45"></circle>
					<path
						id="base-timer-path-remaining"
						stroke-dasharray="283"
						class="base-timer__path-remaining ${remainingPathColor}"
						d="
						M 50, 50
						m -45, 0
						a 45,45 0 1,0 90,0
						a 45,45 0 1,0 -90,0
						"
					></path>
					</g>
				</svg>
				<span id="base-timer-label" class="base-timer__label">${formatTime(
					timeLeft
				)}</span>
				</div>
				`;

				startTimer();
				} else {
					document.getElementById("lddfw_tracking_order_status").style.margin = "80px 0px 0px 0px";
				}

				function onTimesUp() {
					clearInterval(timerInterval);
				}

				function startTimer() {
					timerInterval = setInterval(() => {
						timePassed = timePassed += 1;
						timeLeft = TIME_LIMIT - timePassed;
						document.getElementById("base-timer-label").innerHTML = formatTime(
						timeLeft
						);
						setCircleDasharray();
						setRemainingPathColor(timeLeft);

						if (timeLeft === 0) {
						onTimesUp();
						}
					}, 1000);
				}

				function formatTime(time) {
					const minutes = Math.floor(time / 60);
					let seconds = time % 60;

					if (seconds < 10) {
						seconds = `0${seconds}`;
					}
					return `<span class="tracking_min">${minutes}</span>` + tracking_min_text ;
				}

				function setRemainingPathColor(timeLeft) {
					const { alert, warning, info } = COLOR_CODES;
					if (timeLeft <= alert.threshold) {
						document
						.getElementById("base-timer-path-remaining")
						.classList.remove(warning.color);
						document
						.getElementById("base-timer-path-remaining")
						.classList.add(alert.color);
					} else if (timeLeft <= warning.threshold) {
						document
						.getElementById("base-timer-path-remaining")
						.classList.remove(info.color);
						document
						.getElementById("base-timer-path-remaining")
						.classList.add(warning.color);
					}
				}

				function calculateTimeFraction() {
					const rawTimeFraction = timeLeft / TIME_LIMIT;
					return rawTimeFraction - (1 / TIME_LIMIT) * (1 - rawTimeFraction);
				}

				function setCircleDasharray() {
					const circleDasharray = `${(
						calculateTimeFraction() * FULL_DASH_ARRAY
					).toFixed(0)} 283`;
					document
						.getElementById("base-timer-path-remaining")
						.setAttribute("stroke-dasharray", circleDasharray);
				}

				setInterval(function() {
					window.location.reload();
				  }, 300000);

		    </script>';

			} else {
					// Order is not on out for delivery status.
					wp_redirect( home_url() );
					exit;
				}
			} else {
				// No partner.
				wp_redirect( home_url() );
				exit;
			}
		} else {
			// Order not exist.
			wp_redirect( home_url() );
			exit;
		}
		return $html;
	}

	/**
	 * partners locations.
	 *
	 * @since 1.4.0
	 * @return json
	 */
	public function lddfw_partners_locations() {
			global $wpdb;
			$route               = new LDDFW_Route();
			$wc_query            = $route->lddfw_all_routes_query__premium_only();
			$json                = '';
			$last_lddfw_partnerid = 0;
		if ( $wc_query->have_posts() ) {
			$json = '[';
			while ( $wc_query->have_posts() ) {
				$wc_query->the_post();
				$orderid        = get_the_ID();
				$order          = wc_get_order( $orderid );
				$lddfw_partnerid = $order->get_meta( 'lddfw_partnerid' );
				if ( $last_lddfw_partnerid !== $lddfw_partnerid ) {

					// Get partner tracking status.
					$lddfw_tracking_status = get_user_meta( $lddfw_partnerid, 'lddfw_tracking_status', true );

					// Get partner location from DB.
					$results = $this->lddfw_get_partner_location__premium_only( $lddfw_partnerid );


					$lddfw_tracking_latitude  = '';
					$lddfw_tracking_longitude = '';
					$lddfw_tracking_speed     = '';

					if ( ! empty( $results ) ){
						$lddfw_tracking_latitude  = $results[0]->latitude;
						$lddfw_tracking_longitude = $results[0]->longitude;
						$lddfw_tracking_speed     = $results[0]->speed;
					}

					if ( 0 !== $last_lddfw_partnerid ) {
						$json .= ','; }
					$json .= '{"partner":"' . $lddfw_partnerid . '","tracking":"' . $lddfw_tracking_status . '","lat":"' . $lddfw_tracking_latitude . '","long":"' . $lddfw_tracking_longitude . '" , "speed" : "' . $lddfw_tracking_speed . '" }';
					$last_lddfw_partnerid = $lddfw_partnerid;
				}
				?>
				<?php
			}
				$json .= ']';
		}
		return $json;
	}

	/**
	 * Set partner tracking position.
	 *
	 * @param int    $partner_id partner user id.
	 * @param string $lddfw_latitude latitude.
	 * @param string $lddfw_longitude longitude.
	 * @param string $lddfw_speed speed.
	 * @since 1.4.0
	 * @return int
	 */
	public function lddfw_set_partner_tracking_position( $partner_id, $lddfw_latitude, $lddfw_longitude, $lddfw_speed ) {
		global $wpdb;
		$wpdb->insert( "{$wpdb->prefix}lddfw_tracking", array(
			'partner_id' => $partner_id,
			'latitude' => $lddfw_latitude,
			'longitude' => $lddfw_longitude,
			'speed' => $lddfw_speed,
			'date' => date_i18n( 'Y-m-d H:i:s' ),
		));
		return 1;
	}

	/**
	 * Set partner tracking status.
	 *
	 * @param int    $partner_id partner user id.
	 * @param string $tracking_status tracking status.
	 * @since 1.4.0
	 * @return int
	 */
	public function lddfw_partner_tracking_status( $partner_id, $tracking_status ) 
	{
		update_user_meta( $partner_id, 'lddfw_tracking_status', $tracking_status );
		return 1;
	}

	/**
	 * Admin tracking screen.
	 *
	 * @since 1.4.0
	 */
	public function lddfw_partners_panel_script() {
		global $lddfw_out_for_delivery_counter, $lddfw_partners_tracking_timing, $lddfw_partner_id;
		?>
<script>
	var lddfw_watch_position_id, lddfw_last_latitude, lddfw_last_longitude;

	if (jQuery("#lddfw_trackme").length) {
		if (lddfw_tracking_status == "1") {
			lddfw_switch_tracking_icon("1");
		} else {
			lddfw_switch_tracking_icon("0");
		}
	}

	function lddfw_watch_position_start() {
			<?php
			if ( '1' === $lddfw_partners_tracking_timing ) {
				?>
				lddfw_watch_position_id = setInterval(lddfw_watch_position, 120000 );
				<?php
			}
			?>
	}

	<?php
		// Start watch position.
		if ( 0 < $lddfw_out_for_delivery_counter ) { ?>
		if ( lddfw_tracking_status == "1" ) {
			<?php
				// Track the partner location if the last tracking time is more then 2 minutes.
				$results = $this->lddfw_get_partner_location__premium_only( $lddfw_partner_id );
				if ( ! empty( $results ) ){
					$lddfw_tracking_date = $results[0]->date;
					$seconds_diff = -1 ;
					if ( '' !== $lddfw_tracking_date ) {
						$current_date	 = date_i18n( 'Y-m-d H:i:s' );
						$last_track_date = date( "Y-m-d H:i:s", ( strtotime( date( $lddfw_tracking_date ) ) + 120 ) );
						$seconds_diff    = strtotime( $last_track_date ) - strtotime( $current_date );
					}
					if ( $seconds_diff < -1 ){
						?>
						lddfw_watch_position();
						<?php
					}
				}
			?>
			lddfw_watch_position_start();
		}
	<?php } ?>

</script>
		<?php
	}

	 /**
	 * Get partner_location.
	 *
	 * @param int    $partner_id partner user id.
	 * @return array
	 */
	public function lddfw_get_partner_location__premium_only( $partner_id )
	{
		global $wpdb;
		// Get partner location from DB.
		$results = $wpdb->get_results(
			$wpdb->prepare("SELECT latitude,longitude,speed,date FROM {$wpdb->prefix}lddfw_tracking WHERE partner_id=%d order by id desc limit 1", $partner_id )
		);
		return $results;
	}
// 	Customer function to get live location of partner for assigning order
	public function lddfw_get_partner_live_location__premium_only_( $partner_id )
	{
		global $wpdb;
		// Get partner location from DB.
		$results = $wpdb->get_results(
			$wpdb->prepare("SELECT latitude,longitude FROM {$wpdb->prefix}lddfw_tracking_partner WHERE partner_id=%d order by id desc limit 1", $partner_id )
		);
		return $results;
	}


	/**
	 * Delivery tracking.
	 *
	 * @param int $order_id order number.
	 * @return void
	 */
	public function lddfw_delivery_tracking__premium_only( $order_id ){

		$order = wc_get_order( $order_id );
		$order_status = '';
		$lddfw_tracking_latitude  = '';
		$lddfw_tracking_longitude = '';
		$lddfw_tracking_speed     = '';
		$note = '';
		if( ! empty( $order ) ){

			// Get the partner id.
			$partner_id = get_post_meta( $order_id, 'lddfw_partnerid', true );

			// Order Status.
			$order_status = $order->get_status();

			switch ( 'wc-' . $order_status ) {
				case get_option( 'lddfw_out_for_delivery_status', '' ) :
					$note = esc_attr ( __( 'Your order is on its way', 'lddfw' ) );
					break;
				case get_option( 'lddfw_failed_attempt_status', '' ) :
				 	$note = esc_attr ( __( 'Your order is failed to deliver', 'lddfw' ) );
					break;
				case get_option( 'lddfw_delivered_status', '' ) :
					$note = esc_attr ( __( 'Your order has been delivered', 'lddfw' ) );
					break;
				case get_option( 'lddfw_partner_assigned_status', '' ) :
					$note = esc_attr ( __( 'Your order is now ready and being delivered', 'lddfw' ) );
			}

			// Check if partner exist.
			if ( '' !== $partner_id ){
				// Check if order is out for delivery.
				if ( get_option( 'lddfw_out_for_delivery_status', '' ) === 'wc-' . $order_status ){

					 $array = $this->lddfw_get_partner_location__premium_only( $partner_id );
					 if ( ! empty( $array ) ){
						$lddfw_tracking_latitude  = $array[0]->latitude;
						$lddfw_tracking_longitude = $array[0]->longitude;
						$lddfw_tracking_speed     = $array[0]->speed;
					}
				}
			}
		}
		$result = '{ "order" : "' . $order_id .'" , "status" : "' . $order_status .'", "partner_latitude" : "' . $lddfw_tracking_latitude . '", "partner_longitude" : "' . $lddfw_tracking_longitude . '", "partner_speed" : "' . $lddfw_tracking_speed . '", "note" : "' . $note .'"}';
		echo $result;
	}
}
