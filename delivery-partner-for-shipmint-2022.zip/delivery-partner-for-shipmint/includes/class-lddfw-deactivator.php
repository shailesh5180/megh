<?php
/**
 * Fired during plugin activation
 *
 * @link  http://www.powerfulwp.com
 * @since 1.0.0
 *
 * @package    LDDFW
 * @subpackage LDDFW/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    LDDFW
 * @subpackage LDDFW/includes
 * @author     powerfulwp <cs@powerfulwp.com>
 */
class LDDFW_Deactivator {

private $table_activator;
	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since 1.0.0
	 */

	public function __construct($activator)
    {
        $this->table_activator = $activator;
    }
    
    public function deactivate() {

    	// Find out when the last event was scheduled.
		$timestamp = wp_next_scheduled( 'lddfw_daily_event' );
		// Unschedule previous event if any.
		wp_unschedule_event( $timestamp, 'lddfw_daily_event' );


        global $wpdb;

        $wpdb->query("DROP TABLE IF EXISTS " . $this->table_activator->shipmint_tbl_commission());
        $wpdb->query("DROP TABLE IF EXISTS " . $this->table_activator->shipmint_tbl_tracking_partner());
        $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}lddfw_orders" );
        $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}lddfw_tracking" );
        
       
        
    }
	
}
