<?php


// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
// dropping tables on plugin uninstall
        //$wpdb->query("DROP TABLE IF EXISTS ".$this->table_activator->wp_lddfw_commission());
        //$wpdb->query("DROP TABLE IF EXISTS ". $this->table_activator->wp_lddfw_orders());