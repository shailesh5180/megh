<?php
/*
Plugin Name:	Tutsplus Section Menus
Plugin URI:		https://github.com/rachelmccollin/tutsplus-plugin-development
Description:	Plugin to accompany tutsplus course on plugin development. Adds a section menu to the sidebar.
Version:		2.1
Author:			Rachel McCollin
Author URI:		https://rachelmccollin.com 
TextDomain:		tutsplus
License:		GPLv2
*/