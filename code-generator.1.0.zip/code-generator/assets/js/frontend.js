/**
 * Plugin Template frontend js.
 *
 *  @package WordPress Plugin Template/JS
 */

jQuery( document ).ready(
	function ( e ) {

	}
);
